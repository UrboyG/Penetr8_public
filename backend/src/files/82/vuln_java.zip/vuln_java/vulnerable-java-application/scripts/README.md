These contain sample scripts to push the Docker images to AWS ECR.
