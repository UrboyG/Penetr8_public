package com.datadoghq.workshops.samplevulnerablejavaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleVulnerableJavaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
