package com.datadoghq.workshops.samplevulnerablejavaapp.http;

import lombok.Data;

@Data
public class ViewFileRequest {
    public String path;
}
